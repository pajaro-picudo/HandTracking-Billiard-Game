import math
import numpy as np

class GestureRecognizer:
    """
    Módulo de reconocimiento de gestos para controlar el Tetris.
    
    Gestos implementados:
    - Mano izquierda: Posición X para mover pieza horizontalmente
    - Mano derecha: Rotación de muñeca para rotar pieza
    - Ambas manos abiertas: Soltar pieza y aplicar gravedad
    """
    
    def __init__(self):
        self.prev_rotation_angle = 0
        self.rotation_threshold = 30  # Grados necesarios para rotar
        self.accumulated_rotation = 0
        
    def get_horizontal_position(self, hand_landmarks, screen_width):
        """
        Obtiene la posición horizontal normalizada de la mano izquierda.
        
        Args:
            hand_landmarks: Landmarks de MediaPipe
            screen_width: Ancho de la pantalla del juego
            
        Returns:
            int: Posición X en píxeles
        """
        if not hand_landmarks:
            return None
            
        wrist = hand_landmarks.landmark[0]
        return int(wrist.x * screen_width)
    
    def is_hand_open(self, hand_landmarks):
        """
        Detecta si la mano está completamente abierta.
        
        Criterio: Todos los dedos extendidos (punta más alta que nudillo medio)
        
        Returns:
            bool: True si la mano está abierta
        """
        if not hand_landmarks:
            return False
        
        # Índices de landmarks: [pulgar, índice, medio, anular, meñique]
        finger_tips = [4, 8, 12, 16, 20]
        finger_pips = [2, 6, 10, 14, 18]
        
        open_count = 0
        
        for tip, pip in zip(finger_tips, finger_pips):
            tip_y = hand_landmarks.landmark[tip].y
            pip_y = hand_landmarks.landmark[pip].y
            
            # Dedo extendido si la punta está más arriba que el nudillo
            if tip_y < pip_y - 0.02:  # Umbral pequeño
                open_count += 1
        
        # Mano abierta si al menos 4 dedos están extendidos
        return open_count >= 4
    
    def get_hand_rotation(self, hand_landmarks):
        """
        Calcula el ángulo de rotación de la mano derecha.
        Usa el vector entre muñeca y nudillo del dedo medio.
        
        Returns:
            float: Ángulo en grados [-180, 180]
        """
        if not hand_landmarks:
            return None
        
        wrist = hand_landmarks.landmark[0]
        middle_mcp = hand_landmarks.landmark[9]  # Nudillo del dedo medio
        
        # Calcular vector y ángulo
        dx = middle_mcp.x - wrist.x
        dy = middle_mcp.y - wrist.y
        
        angle = math.degrees(math.atan2(dy, dx))
        return angle
    
    def detect_rotation_gesture(self, hand_landmarks):
        """
        Detecta si se debe rotar la pieza basándose en el giro de muñeca.
        
        Returns:
            int: 1 para rotar horario, -1 para antihorario, 0 para no rotar
        """
        current_angle = self.get_hand_rotation(hand_landmarks)
        
        if current_angle is None:
            return 0
        
        # Calcular diferencia angular
        angle_diff = current_angle - self.prev_rotation_angle
        
        # Normalizar diferencia a rango [-180, 180]
        if angle_diff > 180:
            angle_diff -= 360
        elif angle_diff < -180:
            angle_diff += 360
        
        self.accumulated_rotation += angle_diff
        
        # Detectar rotación
        rotation_command = 0
        if abs(self.accumulated_rotation) >= self.rotation_threshold:
            if self.accumulated_rotation > 0:
                rotation_command = 1  # Rotar horario
            else:
                rotation_command = -1  # Rotar antihorario
            
            self.accumulated_rotation = 0  # Resetear acumulador
        
        self.prev_rotation_angle = current_angle
        return rotation_command
    
    def detect_drop_gesture(self, left_hand, right_hand):
        """
        Detecta si ambas manos están abiertas para soltar la pieza.
        
        Returns:
            bool: True si se debe soltar la pieza
        """
        left_open = self.is_hand_open(left_hand)
        right_open = self.is_hand_open(right_hand)
        
        return left_open and right_open

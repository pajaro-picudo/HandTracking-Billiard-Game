import pygame
import random
from physics_engine import PhysicsEngine

class TetrisGame:
    """
    Lógica principal del juego Tetris con física real.
    """
    
    def __init__(self, screen_width=800, screen_height=600):
        pygame.init()
        
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.screen = pygame.display.set_mode((screen_width, screen_height))
        pygame.display.set_caption("Tetris Físico - Control con Gestos")
        
        self.clock = pygame.time.Clock()
        self.fps = 60
        
        # Motor de física
        self.physics = PhysicsEngine(screen_width, screen_height)
        
        # Estado del juego
        self.current_piece = None
        self.current_piece_blocks = []
        self.block_size = 30
        self.piece_types = ['I', 'O', 'T', 'S', 'Z', 'J', 'L']
        
        self.is_piece_controlled = True  # Pieza bajo control manual
        self.settled_blocks = []  # Bloques que ya cayeron
        
        self.score = 0
        self.lines_cleared = 0
        
        # Colores
        self.bg_color = (20, 20, 40)
        self.text_color = (255, 255, 255)
        
        # Fuente
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        
        # Spawn de nueva pieza
        self.spawn_new_piece()
    
    def spawn_new_piece(self):
        """Crea una nueva pieza en la parte superior."""
        piece_type = random.choice(self.piece_types)
        
        spawn_x = self.screen_width // 2
        spawn_y = 100
        
        self.current_piece_blocks = self.physics.create_tetris_piece(
            piece_type, spawn_x, spawn_y, self.block_size
        )
        
        # El primer elemento contiene el cuerpo principal
        if self.current_piece_blocks:
            self.current_piece = self.current_piece_blocks[0][0]
            self.is_piece_controlled = True
            self.physics.disable_gravity()
    
    def move_piece_horizontal(self, target_x):
        """Mueve la pieza actual horizontalmente."""
        if not self.current_piece or not self.is_piece_controlled:
            return
        
        current_x, current_y = self.current_piece.position
        
        # Limitar movimiento dentro de los bordes
        margin = self.block_size * 2
        target_x = max(margin, min(target_x, self.screen_width - margin))
        
        # Actualizar posición
        self.current_piece.position = target_x, current_y
        self.current_piece.velocity = (0, 0)  # Anular velocidad residual
    
    def rotate_piece(self, direction):
        """Rota la pieza actual."""
        if not self.current_piece or not self.is_piece_controlled:
            return
        
        # Aplicar rotación (90 grados)
        import math
        rotation_amount = math.pi / 2 * direction
        self.current_piece.angle += rotation_amount
    
    def drop_piece(self):
        """Suelta la pieza y activa la gravedad."""
        if not self.current_piece or not self.is_piece_controlled:
            return
        
        self.is_piece_controlled = False
        self.physics.enable_gravity()
        
        # Añadir a bloques settled después de un tiempo
        pygame.time.set_timer(pygame.USEREVENT + 1, 2000, True)
    
    def check_piece_settled(self):
        """Verifica si la pieza actual se ha asentado."""
        if not self.current_piece or self.is_piece_controlled:
            return False
        
        # Verificar si la velocidad es casi cero
        vel_threshold = 10
        if abs(self.current_piece.velocity.y) < vel_threshold:
            self.settled_blocks.extend(self.current_piece_blocks)
            self.current_piece = None
            self.current_piece_blocks = []
            
            # Spawn nueva pieza
            pygame.time.set_timer(pygame.USEREVENT + 2, 1000, True)
            return True
        
        return False
    
    def check_full_rows(self):
        """
        Detecta filas completas y las elimina.
        (Simplificado para demostración)
        """
        # Esta es una implementación básica
        # En producción se necesitaría una detección más robusta
        pass
    
    def update(self, dt):
        """Actualiza el estado del juego."""
        self.physics.update(dt)
        self.check_piece_settled()
    
    def draw_ui(self):
        """Dibuja la interfaz de usuario."""
        # Título
        title = self.font.render("TETRIS FÍSICO", True, self.text_color)
        self.screen.blit(title, (20, 20))
        
        # Puntuación
        score_text = self.small_font.render(f"Score: {self.score}", True, self.text_color)
        self.screen.blit(score_text, (20, 60))
        
        # Instrucciones
        instructions = [
            "MANO IZQUIERDA: Mover horizontalmente",
            "MANO DERECHA: Rotar pieza",
            "AMBAS ABIERTAS: Soltar pieza",
        ]
        
        y_offset = self.screen_height - 100
        for i, instruction in enumerate(instructions):
            text = self.small_font.render(instruction, True, (150, 150, 255))
            self.screen.blit(text, (20, y_offset + i * 25))
    
    def draw_gesture_feedback(self, left_pos, right_rotation, both_open):
        """Dibuja feedback visual de los gestos detectados."""
        feedback_x = self.screen_width - 200
        feedback_y = 20
        
        # Mano izquierda
        if left_pos is not None:
            left_text = self.small_font.render(f"Left X: {left_pos}", True, (0, 255, 0))
            self.screen.blit(left_text, (feedback_x, feedback_y))
        
        # Mano derecha
        if right_rotation is not None:
            right_text = self.small_font.render(f"Rotation: {right_rotation}", True, (0, 255, 0))
            self.screen.blit(right_text, (feedback_x, feedback_y + 30))
        
        # Ambas abiertas
        if both_open:
            drop_text = self.font.render("DROP!", True, (255, 0, 0))
            self.screen.blit(drop_text, (self.screen_width // 2 - 50, 100))
    
    def render(self):
        """Renderiza el juego."""
        self.screen.fill(self.bg_color)
        
        # Dibujar física
        self.physics.draw(self.screen)
        
        # Dibujar UI
        self.draw_ui()
        
        pygame.display.flip()
    
    def handle_events(self):
        """Maneja eventos de Pygame."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            # Timers para spawn de piezas
            if event.type == pygame.USEREVENT + 2:
                self.spawn_new_piece()
        
        return True
    
    def run(self):
        """Loop principal del juego."""
        running = True
        
        while running:
            dt = self.clock.tick(self.fps) / 1000.0
            
            running = self.handle_events()
            self.update(dt)
            self.render()
        
        pygame.quit()

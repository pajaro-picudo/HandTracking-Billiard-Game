import cv2
import pygame
from hand_tracking import HandTracker
from gesture_recognition import GestureRecognizer
from tetris_game import TetrisGame

class TetrisGestureController:
    """
    Integración principal: Cámara → MediaPipe → Gestos → Tetris con Física
    """
    
    def __init__(self):
        # Inicializar módulos
        self.hand_tracker = HandTracker()
        self.gesture_recognizer = GestureRecognizer()
        self.game = TetrisGame(screen_width=800, screen_height=600)
        
        # Cámara
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        
        # Estado de gestos
        self.last_drop_gesture = False
        
    def process_gestures(self, left_hand, right_hand):
        """
        Procesa los gestos detectados y controla el juego.
        
        Returns:
            tuple: (left_x, rotation_cmd, both_open) para feedback visual
        """
        left_x = None
        rotation_cmd = 0
        both_open = False
        
        # Mano izquierda: Mover horizontalmente
        if left_hand:
            left_x = self.gesture_recognizer.get_horizontal_position(
                left_hand, self.game.screen_width
            )
            if left_x:
                self.game.move_piece_horizontal(left_x)
        
        # Mano derecha: Rotar pieza
        if right_hand:
            rotation_cmd = self.gesture_recognizer.detect_rotation_gesture(right_hand)
            if rotation_cmd != 0:
                self.game.rotate_piece(rotation_cmd)
        
        # Ambas manos abiertas: Soltar pieza
        both_open = self.gesture_recognizer.detect_drop_gesture(left_hand, right_hand)
        if both_open and not self.last_drop_gesture:
            self.game.drop_piece()
        
        self.last_drop_gesture = both_open
        
        return left_x, rotation_cmd, both_open
    
    def run(self):
        """Loop principal de la aplicación."""
        print("=== TETRIS FÍSICO CON CONTROL DE GESTOS ===")
        print("Instrucciones:")
        print("- Mano IZQUIERDA: Mover pieza horizontalmente")
        print("- Mano DERECHA: Rotar pieza (gira la muñeca)")
        print("- AMBAS MANOS ABIERTAS: Soltar pieza")
        print("- Presiona 'Q' en la ventana de cámara para salir")
        print("==========================================\n")
        
        running = True
        
        while running:
            # Capturar frame de cámara
            ret, frame = self.cap.read()
            if not ret:
                print("Error al capturar frame de cámara")
                break
            
            # Detectar manos
            left_hand, right_hand, annotated_frame = self.hand_tracker.process_frame(frame)
            
            # Procesar gestos y controlar juego
            left_x, rotation, both_open = self.process_gestures(left_hand, right_hand)
            
            # Actualizar juego
            dt = self.game.clock.tick(self.game.fps) / 1000.0
            self.game.update(dt)
            
            # Renderizar juego con feedback de gestos
            self.game.screen.fill(self.game.bg_color)
            self.game.physics.draw(self.game.screen)
            self.game.draw_ui()
            self.game.draw_gesture_feedback(left_x, rotation, both_open)
            pygame.display.flip()
            
            # Mostrar ventana de cámara con detección de manos
            cv2.imshow("Control de Gestos - Tetris", annotated_frame)
            
            # Manejar eventos
            running = self.game.handle_events()
            
            # Salir con 'Q' en ventana de cámara
            if cv2.waitKey(1) & 0xFF == ord('q'):
                running = False
        
        # Limpieza
        self.cap.release()
        cv2.destroyAllWindows()
        self.hand_tracker.release()
        pygame.quit()
        print("\n¡Gracias por jugar!")

if __name__ == "__main__":
    controller = TetrisGestureController()
    controller.run()

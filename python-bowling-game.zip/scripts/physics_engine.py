import pymunk
import pymunk.pygame_util
import pygame

class PhysicsEngine:
    """
    Motor de física usando Pymunk para simular caída y colisiones realistas.
    """
    
    def __init__(self, screen_width, screen_height):
        self.space = pymunk.Space()
        self.space.gravity = (0, 0)  # Gravedad se activa al soltar pieza
        
        self.screen_width = screen_width
        self.screen_height = screen_height
        
        # Parámetros físicos
        self.block_mass = 1
        self.block_friction = 0.7
        self.block_elasticity = 0.1
        
        # Crear bordes del tablero
        self._create_boundaries()
        
        # Draw options para debug
        self.draw_options = None
        
    def _create_boundaries(self):
        """Crea los bordes estáticos del tablero."""
        static_body = self.space.static_body
        
        # Grosor de paredes
        thickness = 10
        
        # Paredes laterales y suelo
        walls = [
            # Suelo
            pymunk.Segment(static_body, (0, self.screen_height), 
                          (self.screen_width, self.screen_height), thickness),
            # Pared izquierda
            pymunk.Segment(static_body, (0, 0), (0, self.screen_height), thickness),
            # Pared derecha
            pymunk.Segment(static_body, (self.screen_width, 0), 
                          (self.screen_width, self.screen_height), thickness),
        ]
        
        for wall in walls:
            wall.friction = 0.7
            wall.elasticity = 0.1
            self.space.add(wall)
    
    def create_tetris_block(self, x, y, size, shape_type='square'):
        """
        Crea un bloque físico de Tetris.
        
        Args:
            x, y: Posición inicial
            size: Tamaño del bloque
            shape_type: Tipo de forma para diferentes piezas
            
        Returns:
            tuple: (body, shape)
        """
        moment = pymunk.moment_for_box(self.block_mass, (size, size))
        body = pymunk.Body(self.block_mass, moment)
        body.position = x, y
        
        shape = pymunk.Poly.create_box(body, (size, size))
        shape.friction = self.block_friction
        shape.elasticity = self.block_elasticity
        
        self.space.add(body, shape)
        
        return body, shape
    
    def create_tetris_piece(self, piece_type, x, y, block_size):
        """
        Crea una pieza completa de Tetris con múltiples bloques unidos.
        
        Args:
            piece_type: 'I', 'O', 'T', 'S', 'Z', 'J', 'L'
            x, y: Posición central
            block_size: Tamaño de cada bloque
            
        Returns:
            list: Lista de (body, shape) tuples
        """
        # Definir formas de Tetris (coordenadas relativas)
        shapes = {
            'I': [(0, 0), (1, 0), (2, 0), (3, 0)],
            'O': [(0, 0), (1, 0), (0, 1), (1, 1)],
            'T': [(1, 0), (0, 1), (1, 1), (2, 1)],
            'S': [(1, 0), (2, 0), (0, 1), (1, 1)],
            'Z': [(0, 0), (1, 0), (1, 1), (2, 1)],
            'J': [(0, 0), (0, 1), (1, 1), (2, 1)],
            'L': [(2, 0), (0, 1), (1, 1), (2, 1)],
        }
        
        blocks = []
        coords = shapes.get(piece_type, shapes['O'])
        
        # Crear cuerpo principal para la pieza
        moment = pymunk.moment_for_box(self.block_mass * len(coords), 
                                       (block_size * 4, block_size * 4))
        main_body = pymunk.Body(self.block_mass * len(coords), moment)
        main_body.position = x, y
        
        # Crear bloques como formas del mismo cuerpo
        for i, (bx, by) in enumerate(coords):
            offset_x = (bx - 1.5) * block_size
            offset_y = (by - 0.5) * block_size
            
            vertices = [
                (offset_x, offset_y),
                (offset_x + block_size, offset_y),
                (offset_x + block_size, offset_y + block_size),
                (offset_x, offset_y + block_size)
            ]
            
            shape = pymunk.Poly(main_body, vertices)
            shape.friction = self.block_friction
            shape.elasticity = self.block_elasticity
            shape.color = self._get_piece_color(piece_type)
            
            blocks.append((main_body, shape))
        
        # Añadir solo el cuerpo una vez y todas las formas
        self.space.add(main_body)
        for _, shape in blocks:
            self.space.add(shape)
        
        return blocks
    
    def _get_piece_color(self, piece_type):
        """Retorna color RGB para cada tipo de pieza."""
        colors = {
            'I': (0, 255, 255),    # Cyan
            'O': (255, 255, 0),    # Amarillo
            'T': (128, 0, 128),    # Púrpura
            'S': (0, 255, 0),      # Verde
            'Z': (255, 0, 0),      # Rojo
            'J': (0, 0, 255),      # Azul
            'L': (255, 165, 0),    # Naranja
        }
        return colors.get(piece_type, (255, 255, 255))
    
    def update(self, dt):
        """Actualiza la simulación física."""
        self.space.step(dt)
    
    def enable_gravity(self):
        """Activa la gravedad (cuando se suelta la pieza)."""
        self.space.gravity = (0, 900)
    
    def disable_gravity(self):
        """Desactiva la gravedad (para controlar pieza manualmente)."""
        self.space.gravity = (0, 0)
    
    def remove_body(self, body, shape):
        """Elimina un cuerpo y forma del espacio físico."""
        if body in self.space.bodies:
            self.space.remove(body, shape)
    
    def draw(self, screen):
        """Dibuja todos los objetos físicos en la pantalla."""
        if self.draw_options is None:
            self.draw_options = pymunk.pygame_util.DrawOptions(screen)
        
        self.space.debug_draw(self.draw_options)
